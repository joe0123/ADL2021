wget https://www.dropbox.com/s/4ujo66r695cdjn3/models.zip?dl=0 -O models.zip
unzip models.zip
