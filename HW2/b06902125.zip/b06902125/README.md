# ADL 2021

## Context Selection / Relevance Choice

### Training

```shell
cd RelChoice/
python make_data.py -q dataset/train.json -c dataset/context.json -o train -s 0
python train.py --train_file task_data/train_0.json --model_name hfl/chinese-xlnet-base
```

## Question Answering

### Training

```shell
cd QuesAns/
python make_data.py -q dataset/train.json -c dataset/context.json -o train -s 0
python train.py --train_file task_data/train_0.json  --model_name hfl/chinese-roberta-wwm-ext-large
```
