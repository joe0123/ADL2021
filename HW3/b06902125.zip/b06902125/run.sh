python3.8 predict.py --test_file $1 --out_file $2 --target_dir mt5_small --beam_size 5
