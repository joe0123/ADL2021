wget https://www.dropbox.com/s/nlc6jxb5go7dh8x/models.zip?dl=1 -O models.zip
unzip models.zip
