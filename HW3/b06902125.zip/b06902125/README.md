# ADL 2021

## Training

### Supervised Leraning

```shell
python train.py --train_file data/train.jsonl --model_name google/mt5-small
```

### Reinforcement Leraning

```shell
python train.py --train_file data/train.jsonl --model_name mt5_small --rl_ratio 1 --epoch_num 5 --lr 3e-5
```
