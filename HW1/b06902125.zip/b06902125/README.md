# ADL 2021

## Intent classification
### Training
```shell
python3.8 train.py --task intent --data_dir /path/to/data_dir --sched_name cosine --embed_lr 0 --no_eval
```

## Slot tagging
### Training
```shell
python3.8 train.py --task slot --data_dir /path/to/data_dir --cri_name crf --sched_name cosine --embed_lr 2e-5 --no_eval
```
