python3.8 infer.py --test_file "${1}" --ckpt_dir ckpt/slot/ --pred_file "${2}"
