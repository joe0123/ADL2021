wget https://www.dropbox.com/s/y07gyspvu5g8ybv/ckpt.zip?dl=1 -O ckpt.zip
unzip ckpt.zip
